DURAND TECH - PACOTE VERCEL
1. Copie a pasta app/ para a raiz do seu projeto Next.js
2. Se ja existir app/page.tsx (sua home), NAO substitua, mantenha
3. git add . && git commit -m "feat: login trial" && git push
Rotas:
- /login -> cadastro + login
- /app -> dashboard protegido
- /leads -> painel privado de leads
Login master: durandtechsysten@gmail.com / durand2026
