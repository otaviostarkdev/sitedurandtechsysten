
export default function Home(){
  return (
    <div className="min-h-screen bg-[#050507] text-white relative overflow-hidden">
      {/* Glow Orbs */}
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-[#00FF88] rounded-full blur-[150px] opacity-[0.08]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[800px] h-[800px] bg-[#7C3AED] rounded-full blur-[180px] opacity-[0.10]" />
      </div>

      {/* Top Bar */}
      <div className="relative z-10 border-b border-white/[0.06] bg-black/30 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-6 py-2 flex justify-between text-[11px] tracking-widest text-zinc-400">
          <span>⚡ (53) 99707-3648 • @durandtechsysten • PIX durandtechsysten@gmail.com</span>
          <span className="hidden md:block text-[#00FF88]">● Sistema Online • Pelotas/RS</span>
        </div>
      </div>

      {/* Navbar */}
      <nav className="relative z-10 sticky top-0 border-b border-white/[0.06] bg-black/50 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#00FF88] flex items-center justify-center text-black font-black text-sm">D</div>
            <span className="font-bold tracking-tight">DurandTech<span className="text-zinc-500 font-normal">Systen</span></span>
          </div>
          <div className="hidden md:flex gap-8 text-sm text-zinc-400">
            <a href="#servicos" className="hover:text-white transition">Serviços</a>
            <a href="#portfolio" className="hover:text-white transition">Portfólio</a>
            <a href="#maquininha" className="hover:text-white transition">Maquininha</a>
          </div>
          <a href="https://wa.me/5553997073648" className="shine bg-[#00FF88] text-black px-5 py-2.5 rounded-full text-sm font-bold hover-lift">Fazer Orçamento →</a>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 pt-20 pb-12">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-[11px] text-zinc-300 mb-6">
              <span className="w-2 h-2 bg-[#00FF88] rounded-full animate-pulse" /> 5 anos de experiência • Suporte direto Pelotas/RS
            </div>
            <h1 className="text-[42px] md:text-[56px] font-black leading-[0.95] tracking-tight">Sites modernos,<br/>sistemas <span className="text-[#00FF88]">poderosos</span><br/>que vendem</h1>
            <p className="mt-6 text-[16px] leading-relaxed text-zinc-400 max-w-[480px]">Construção de sites otimizados, responsivos, sistemas, APIs, softwares e apps Android. Focados em performance, SEO e conversão para seu negócio crescer.</p>
            <div className="mt-8 flex gap-3">
              <a href="https://wa.me/5553997073648" className="shine bg-white text-black px-6 py-3 rounded-full font-bold text-sm hover-lift">Começar Projeto</a>
              <a href="#portfolio" className="glass px-6 py-3 rounded-full font-medium text-sm hover-lift">Ver Portfólio</a>
            </div>
            <div className="mt-8 flex gap-6 text-xs text-zinc-500">
              <span>✓ PIX durandtechsysten@gmail.com</span>
            </div>
          </div>

          {/* Terminal Glass */}
          <div className="glass-strong rounded-[20px] p-6 shadow-2xl relative">
            <div className="flex gap-2 mb-4"><div className="w-3 h-3 rounded-full bg-red-500/80" /><div className="w-3 h-3 rounded-full bg-yellow-500/80" /><div className="w-3 h-3 rounded-full bg-green-500/80" /></div>
            <div className="font-mono text-[13px] leading-7">
              <div className="text-zinc-500">durandtech@server:~</div>
              <div className="text-white">$ npm run build:durandtech <span className="blink">_</span></div>
              <div className="text-[#00FF88] mt-2">&gt; Building optimized site...</div>
              <div className="mt-3 space-y-1 text-zinc-300">
                <div>✓ Sites responsivos 100%</div>
                <div>✓ Sistemas escaláveis</div>
                <div>✓ APIs REST seguras</div>
                <div>✓ Apps Android nativos</div>
                <div className="text-[#FFD700]">✓ CondoManager PRO v2.6</div>
              </div>
              <div className="mt-4 text-[#00FF88]">$ Deploy em produção: durandtechsysten.com.br 🚀</div>
            </div>
            <div className="absolute -bottom-6 -right-6 glass rounded-xl px-4 py-2 text-xs">⚡ 100/100 PageSpeed</div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="servicos" className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        <h2 className="text-3xl font-black tracking-tight">Serviços que escalam seu negócio</h2>
        <p className="text-zinc-500 mt-2 text-sm">Do site institucional ao sistema complexo, tudo com código limpo e performance</p>
        <div className="mt-8 grid md:grid-cols-3 gap-4">
          {[
            {i:'🌐', t:'Sites Otimizados', d:'Sites ultra rápidos, SEO otimizado, 100/100 PageSpeed, com animações CSS modernas e conversão.'},
            {i:'📱', t:'Sites Responsivos', d:'Adaptado perfeitamente para celular, tablet e desktop. Mobile-first de verdade.'},
            {i:'✨', t:'Sites Modernos', d:'Design 2026, dark mode, glassmorphism, micro-interações que impressionam.', highlight:true},
            {i:'⚙️', t:'Desenvolvimento de Sistemas', d:'Sistemas sob medida, ERPs, CRMs, dashboards. Do zero ao deploy.'},
            {i:'🔌', t:'APIs e Integrações', d:'APIs REST seguras, integração com PIX, WhatsApp, gateways e qualquer serviço.'},
            {i:'🤖', t:'Apps Android', d:'Aplicativos nativos e híbridos, publicamos na Play Store com suporte.'},
          ].map((s,k)=>(
            <div key={k} className={"glass rounded-[16px] p-6 hover-lift " + (s.highlight?'ring-1 ring-[#00FF88]/30':'')}>
              <div className="text-2xl">{s.i}</div>
              <h3 className="mt-3 font-bold text-[15px]">{s.t}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-zinc-400">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Portfolio */}
      <section id="portfolio" className="relative z-10 max-w-6xl mx-auto px-6 py-12">
        <div className="flex justify-between items-end">
          <div><h2 className="text-2xl font-black">Portfólio Completo</h2><p className="text-xs text-zinc-500 mt-1">4 produtos oficiais • Todos abrem em nova aba</p></div>
          <div className="text-xs text-zinc-500">Pelotas/RS → Brasil</div>
        </div>
        <div className="mt-6 grid md:grid-cols-4 gap-4">
          {[
            {n:'CondoManager PRO v2.6', tag:'PRO', color:'#FFD700'},
            {n:'Sites Institucionais', tag:'WEB'},
            {n:'Sistemas ERP/CRM', tag:'SISTEMA'},
            {n:'Apps Android', tag:'APP'},
          ].map((p,i)=>(
            <div key={i} className="glass rounded-[14px] p-5 hover-lift group cursor-pointer">
              <div className="flex justify-between"><span className="text-[10px] px-2 py-1 rounded-full bg-white/10">{p.tag}</span>{p.color && <span className="text-[10px] px-2 py-1 rounded-full bg-[#FFD700] text-black font-bold">POPULAR</span>}</div>
              <div className="mt-8 font-bold text-sm group-hover:text-[#00FF88] transition">{p.n}</div>
              <div className="mt-2 text-[11px] text-zinc-500">Ver projeto →</div>
            </div>
          ))}
        </div>
      </section>

      {/* Maquininha */}
      <section id="maquininha" className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        <div className="glass-strong rounded-[24px] p-8 md:p-10 flex flex-col md:flex-row justify-between gap-8">
          <div>
            <h2 className="text-2xl font-black">Máquina de Cartão Smart</h2>
            <p className="text-sm text-zinc-400 mt-2 max-w-[400px]">Aceite PIX, crédito e débito com as melhores taxas - PIX durandtechsysten@gmail.com</p>
            <div className="mt-6 grid grid-cols-3 gap-3">
              {[{t:'Taxa Zero no PIX', d:'Receba na hora'},{t:'Link de Pagamento', d:'Cobre no WhatsApp'},{t:'Entrega Pelotas/RS', d:'Configuramos tudo'}].map((c,i)=><div key={i} className="glass rounded-xl p-3"><div className="text-xs font-bold">{c.t}</div><div className="text-[11px] text-zinc-500 mt-1">{c.d}</div></div>)}
            </div>
          </div>
          <div className="flex flex-col gap-3 min-w-[220px]">
            <a href="https://wa.me/5553997073648" className="shine bg-[#00FF88] text-black rounded-full py-3 text-center font-bold text-sm hover-lift">💳 Pedir Maquininha - (53) 99707-3648</a>
            <div className="glass rounded-full py-2 text-center text-xs text-zinc-400">PIX: durandtechsysten@gmail.com</div>
          </div>
        </div>
      </section>

      <footer className="relative z-10 border-t border-white/[0.06] mt-10 py-8 text-center text-[11px] text-zinc-500">
        DurandTechSysten © 2026 • Sites, Sistemas e CondoManager PRO • Pelotas/RS • Feito com Obsidian Glass 2026
      </footer>
    </div>
  )
}
