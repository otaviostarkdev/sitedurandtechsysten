
import './globals.css'
export const metadata = { title: 'Durand Tech System - Sites, Sistemas e CondoManager PRO | Pelotas RS', description: 'Sites modernos, sistemas poderosos que vendem. 5 anos de experiência, Pelotas/RS' }
export default function RootLayout({children}:{children:React.ReactNode}){ return (<html lang="pt-BR"><body>{children}</body></html>) }
